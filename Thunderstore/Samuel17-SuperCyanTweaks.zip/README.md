# SuperCyanTweaks

My simpler tweaks will go inside this mod instead of polluting Thunderstore with a bunch of smaller mods. Refer to the `Wiki` tab for more information.

You may turn off each change at your convenience.

## Credits

* .score, Moffein, Nuxlar & Wolfo, for writing helpful and sometimes yoinkable code.
* The denizens of `#development`, for answering my questions. Shoutouts MysticalChicken.

## Contact

Direct your feedback & bug reports to `samuel17` on Discord, either through DMs or the Risk of Rain 2 Modding Discord.